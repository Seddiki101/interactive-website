<?php

require_once './UtilisateurC.php';

require_once ('../model/Utilisateur.php');

$util = new Utilisateur("ok","houssem","houssem","houssem","houssem",123);
$utilC = new UtilisateurC();

// $utilC->ajouterUtilisateur($util);
// $utilC->supprimerUtilisateur(27);
// $utilC->modifierUtilisateur($util, 28);
// $utilC->modifierUtilisateur($util, 28);

// var_dump($utilC->afficherUtilisateurs()->fetchAll());
// var_dump($utilC->recupererUtilisateur(28));
var_dump($utilC->connexionUser("houssem", "houssem"));
?>