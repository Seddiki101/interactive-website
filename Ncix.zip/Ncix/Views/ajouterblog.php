<?php
    include_once 'C:\xampp\htdocs\Ncix\Model\blog.php';
    include_once 'C:\xampp\htdocs\Ncix\Controller\blogC.php';

    $error = "";

    // create blog
    $blog = null;

    // create an instance of the controller
    $blogC = new blogC();
    if (
        isset($_POST["id"]) &&  
        isset($_POST["nom"]) &&     
        isset($_POST["email"]) && 
        isset($_POST["comment"])
    ) {
        if (
            !empty($_POST['id']) &&
            !empty($_POST['nom']) &&
            !empty($_POST["email"]) && 
            !empty($_POST["comment"])
        ) {
            $blog = new blog(
                $_POST['id'],
                $_POST['nom'],
                $_POST['email'],
                $_POST['comment']
            );
            $blogC->ajouterblog($blog);
            header('Location:afficherblog.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>
    <body>
        <button><a href="afficherblog.php">Retour à la liste des blogs</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
        
        <form action="" method="POST">
            <table border="1" align="center">
                 <tr>
                    <td>
                        <label for="nom">ID:
                        </label>
                    </td>
                    <td><input type="text" name="id" id="id" maxlength="20"></td>
                </tr>
               <tr>
                    <td>
                        <label for="nom">Nom:
                        </label>
                    </td>
                    <td><input type="text" name="nom" id="nom" maxlength="20"></td>
                </tr>
                <tr>
               
                
                <tr>
                    <td>
                        <label for="email">Adresse mail:
                        </label>
                    </td>
                    <td>
                        <input type="email" name="email" id="email">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="comment">Comment:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="comment" id="comment" >
                    </td>
                </tr>              
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Envoyer"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>