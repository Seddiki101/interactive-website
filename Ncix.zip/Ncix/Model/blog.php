<?php
	class blog{
		private $id=null;
		private $nom=null;
		private $email=null;
		private $comment;
		
		function __construct($id, $nom, $email, $comment){
			$this->id=$id;
			$this->nom=$nom;
			$this->email=$email;
			$this->comment=$comment;
		}
		function getid(){
			return $this->id;
		}
		function getnom(){
			return $this->nom;
		}


		function getemail(){
			return $this->email;
		}
		function getcomment(){
			return $this->comment;
		}
		function setid(string $id){
			$this->id=$id;
		}
		
		function setnom(string $nom){
			$this->nom=$nom;
		}


		function setemail(string $email){
			$this->email=$email;
		}
		function setcomment(string $comment){
			$this->comment=$comment;
		}
		
	}


?>