<?php
	include 'C:\xampp\htdocs\Ncix\config.php';
	include_once 'C:\xampp\htdocs\Ncix\Model\blog.php';
	class blogC {
		function afficherblog(){
			$sql="SELECT * FROM blog";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function supprimerblog($id){
			$sql="DELETE FROM blog WHERE id=:id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id', $id);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function ajouterblog($blog){
			$sql="INSERT INTO blog (id, nom, email, comment) 
			VALUES (:id,:nom,:email,:comment)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id' => $blog->getid(),
					'nom' => $blog->getnom(),
					'email' => $blog->getemail(),
					'comment' => $blog->getcomment()
				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recupererblog($id){
			$sql="SELECT * from blog where id=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$blog=$query->fetch();
				return $blog;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifierblog($blog, $id){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE blog SET 
						nom= :nom, 
						email= :email, 
						comment= :comment
					WHERE id= :id'
				);
				$query->execute([
					'nom' => $blog->getnom(),
					'email' => $blog->getEmail(),
					'comment' => $blog->getcomment(),
					'id' => $id
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
?>