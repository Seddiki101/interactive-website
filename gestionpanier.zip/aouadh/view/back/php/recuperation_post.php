<?php
$modep=$_POST['modep'];
$rib=$_POST['rib'];
$cb=$_POST['cb'];
$ce=$_POST['ce'];

?>