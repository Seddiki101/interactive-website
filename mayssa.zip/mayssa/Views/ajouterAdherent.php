<?php
    include_once '../Model/Adherent.php';
    include_once '../Controller/AdherentC.php';

    $error = "";

    // create adherent
    $adherent = null;

    // create an instance of the controller
    $adherentC = new AdherentC();
    if (
        isset($_POST["numadherent"]) &&
		isset($_POST["nom"]) &&		
        isset($_POST["prenom"]) &&
		isset($_POST["adresse"]) && 
        isset($_POST["email"]) && 
        isset($_POST["dateins"])
    ) {
        if (
            !empty($_POST["numadherent"]) && 
			!empty($_POST['nom']) &&
            !empty($_POST["prenom"]) && 
			!empty($_POST["adresse"]) && 
            !empty($_POST["email"]) && 
            !empty($_POST["dateins"])
        ) {
            $adherent = new Adherent(
                $_POST['numadherent'],
				$_POST['nom'],
                $_POST['prenom'], 
				$_POST['adresse'],
                $_POST['email'],
                $_POST['dateins']
            );
            $adherentC->ajouteradherent($adherent);
            header('Location:terms.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<html lang="en">
<head>
    
    
    
    
    <title> host 🐘 </title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/css/host.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>

</head>
    <body>
        <button><a href="afficherListeAdherents.php">Retour à la liste des adherents</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
        
        <div>
					<form method="POST" action="" name="f1" onsubmit = "" >
						Username: <input type="text" name="numadherent" id="numadherent" maxlength="20">
						Nom : <input type="text" name="nom" id="nom" maxlength="20">
						<br />
						<br />
						Mot de Passe:   <input type="password" name="prenom" id="prenom" maxlength="20">
						<br />
						<br />
						Adresse: <input type="text" name="adresse" id="adresse">
						Adresse email:  <input type="email" name="email" id="email">
						<br />
						<br />
						Date de naissance:  <input type="date" name="dateins" id="dateins" >
						<br />
						<input type = "submit" value = "M'inscrire">
					</form>
				</div>




        <script src="assets/js/jquery.min.js"></script>
			<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
    </body>
</html>