﻿<?php
	include '../Controller/AdherentC.php';
	$adherentC=new AdherentC();
	$listeAdherents=$adherentC->afficheradherents(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control Panel</title>
    <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
    <link type="text/css" href="css/theme.css" rel="stylesheet">
    <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
    <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
        rel='stylesheet'>
</head>
<body>
    <center><h1>Liste des adherents</h1></center>
		
			
			<?php
				foreach($listeAdherents as $adherent)
			?>
			
				<?php echo   $adherent['NumAdherent']; ?>
				<?php echo  $adherent['Nom']; ?>
				<?php echo  $adherent['Prenom']; ?>
				<?php echo  $adherent['Adresse']; ?>
				<?php echo  $adherent['Email']; ?>
				<?php echo  $adherent['DateInscription']; ?>
				
					<form method="POST" action="modifieradherent.php">
						<input type="submit" name="Modifier" value="Modifier">
						<input type="hidden" value=<?PHP echo $adherent['NumAdherent']; ?> name="NumAdherent">
					</form>
				
				
					<a href="other-user-listing.php?NumAdherent=<?php echo $adherent['NumAdherent']; ?>">Supprimer</a>






    <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
</body>
</html>
