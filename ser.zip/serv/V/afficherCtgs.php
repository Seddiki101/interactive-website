<?php
	
    include '../C/CSC.php';
	$categorieSerC=new CategorieSerC();
	$listeCtgser=$categorieSerC->afficherCat_ser(); 
?>
<html>
	<head></head>
	<body>
	    <button><a href="ajouterCtgs.php">Ajouter une Categorie de service </a></button>
		<center><h1>Liste des Categories</h1></center>
		<table border="1" align="center">
			<tr>
				<th>Identifiant CS </th>
				<th>Nom</th>
				<th>Image</th>
				
				<th>Modifier</th>
				<th>Supprimer</th>
			</tr>
			<?php
				foreach($listeCtgser as $categorie_Service){
			?>
			<tr>
				<td><?php echo $categorie_Service['ID_cs']; ?></td>
				<td><?php echo $categorie_Service['nom_cs']; ?></td>
				<td><?php echo $categorie_Service['image_cs']; ?></td>
				
				<td>
					<form method="POST" action="modifierCtgs.php">
						<input type="submit" name="Modifier" value="Modifier">
						<input type="hidden" value=<?PHP echo $categorie_Service['ID_cs']; ?> name="ID_cs">
					</form>
				</td>
				<td>
					<a href="supprimerCtgs.php?ID_cs=<?php echo $categorie_Service['ID_cs']; ?>">Supprimer</a>
				</td>
			</tr>
			<?php
				}
			?>
		</table>
	</body>
</html>
