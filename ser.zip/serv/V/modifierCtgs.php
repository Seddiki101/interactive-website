<?php
    include_once '../M/CS.php';
    include_once '../C/CSC.php';

    $error = "";

    // create 
    $categorie_Service = null;

    // create an instance of the controller
    $categorieSerC = new CategorieSerC();
    if (
        isset($_POST["ID_cs"]) &&
		isset($_POST["nom_cs"]) &&		
        isset($_POST["image_cs"]) 
		
    ) {
        if (
            !empty($_POST["ID_cs"]) && 
			!empty($_POST['nom_cs']) &&
            !empty($_POST["image_cs"])  
			
			) 
			{
            $categorie_Service = new Categorie_Service(
				$_POST['nom_cs'],
                $_POST['image_cs'], 
				
            );
            $categorieSerC->modifierCat_ser($categorie_Service, $_POST["ID_cs"]);
            header('Location:afficherCtgs.php');
        }
        else
            $error = "Missing information";
    }    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>
    <body>
        <button><a href="afficherctgs.php">Retour à la liste des categories</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
			
		<?php
			if (isset($_POST['ID_cs'])){
				$categorie_Service = $categorieSerC->recupererCat_ser($_POST['ID_cs']);
				
		?>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="ID_cs">Id categorie de service:
                        </label>
                    </td>
                    <td><input type="number" name="ID_cs" id="ID_cs" value="<?php echo $categorie_Service['ID_cs']; ?>" maxlength="20"></td>
                </tr>
				<tr>
                    <td>
                        <label for="nom_cs">Nom:
                        </label>
                    </td>
                    <td><input type="text" name="nom_cs" id="nom_cs" value="<?php echo $categorie_Service['nom_cs']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="image_cs">Image:
                        </label>
                    </td>
                    <td><input type="text" name="image_cs" id="image_cs" value="<?php echo $categorie_Service['image_cs']; ?>" maxlength="21"></td>
                </tr>
                              
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modifier"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
		}
		?>
    </body>
</html>