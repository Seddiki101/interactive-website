<?php
    include '../C/CSC.php';
	$categorieSerC=new CategorieSerC();
	$categorieSerC->supprimerCat_ser($_GET["ID_cs"]);
	header('Location:afficherCtgs.php');
?>