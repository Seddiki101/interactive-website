<?php
    include_once '../M/CS.php';
    include_once '../C/CSC.php';

    $error = "";

    // create adherent
    $service = null;

    // create an instance of the controller
    $serviceC = new ServiceC();
    if (
        isset($_POST["IDs"]) &&
		isset($_POST["nom_ser"]) &&		
        isset($_POST["image_ser"]) &&
		isset($_POST["frais"]) && 
        isset($_POST["Description"]) && 
        isset($_POST["ID_cs"])
    ) {
        if (
            !empty($_POST["IDs"]) && 
			!empty($_POST['nom_ser']) &&
            !empty($_POST["image_ser"]) && 
			!empty($_POST["frais"]) && 
            !empty($_POST["Description"]) && 
            !empty($_POST["ID_cs"])
        ) {
            $service = new Service(
				$_POST['nom_ser'],
                $_POST['image_ser'], 
				$_POST['frais'],
                $_POST['Description'],
                $_POST['ID_cs']
            );
			/*$service->setIDs($_POST['IDs']);
			$service->setNomser($_POST['nom_ser']);
			$service->setImageser($_POST['image_ser']);
			$service->setFrais($_POST['frais']);
			$service->setDesc($_POST['Description']);
			$service->setIDcs($_POST['ID_cs']);*/
            $serviceC->modifierservice($service, $_POST["IDs"]);
            header('Location:afficherSe.php');
        }
        else
            $error = "Missing information";
    }    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>
    <body>
        <button><a href="afficherListeAdherents.php">Retour à la liste des service</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
			
		<?php
			if (isset($_POST['IDs'])){
				$service = $serviceC->recupererservice($_POST['IDs']);
				
		?>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="IDs">ID:
                        </label>
                    </td>
                    <td><input type="text" name="IDs" id="IDs" value="<?php echo $service['IDs']; ?>" maxlength="20"></td>
                </tr>
				<tr>
                    <td>
                        <label for="nom_ser">Nom:
                        </label>
                    </td>
                    <td><input type="text" name="nom_ser" id="nom_ser" value="<?php echo $service['nom_ser']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="image_ser">Image_ser:
                        </label>
                    </td>
                    <td><input type="text" name="image_ser" id="image_ser" value="<?php echo $service['image_ser']; ?>"></td>
                </tr>
                <tr>
                    <td>
                        <label for="frais">Frais:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="frais" value="<?php echo $service['frais']; ?>" id="frais">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="Description">Description:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="Description" id="Description" value="<?php echo $service['Description']; ?>">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="ID_cs">ID_cs:
                        </label>
                    </td>
                    <td>
                        <input type="number" name="ID_cs" id="ID_cs" value="<?php echo $service['ID_cs']; ?>">
                    </td>
                </tr>              
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modifier"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
		}
		?>
    </body>
</html>