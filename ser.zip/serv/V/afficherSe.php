<?php
	include '../C/CSC.php';
	$serviceC=new ServiceC();
	$listeService=$serviceC->afficherservice(); 
?>
<html>
	<head></head>
	<body>
	    <button><a href="ajouterSe.php">Ajouter un service</a></button>
		<center><h1>Liste des services</h1></center>
		<table border="1" align="center">
			<tr>
				<th>Num </th>
				<th>Nom</th>
				<th>image</th>
				<th>frais</th>
				<th>Description</th>
				<th>Num categorie</th>
				<th>Modifier</th>
				<th>Supprimer</th>
			</tr>
			<?php
				foreach($listeService as $service){
			?>
			<tr>
				<td><?php echo $service['IDs']; ?></td>
			    <td><?php echo $service['nom_ser']; ?></td>
				<td><?php echo $service['image_ser']; ?></td>
				<td><?php echo $service['frais']; ?></td>
				<td><?php echo $service['Description']; ?></td>
				<td><?php echo $service['ID_cs']; ?></td>
				<td>
					<form method="POST" action="modifierSe.php">
						<input type="submit" name="Modifier" value="Modifier">
						<input type="hidden" value=<?PHP echo $service['IDs']; ?> name="IDs">
					</form>
				</td>
				<td>
					<a href="supprimerSe.php?IDs=<?php echo $service['IDs']; ?>">Supprimer</a>
				</td>
			</tr>
			<?php
				}
			?>
		</table>
	</body>
</html>
