<?php
include_once '../M/CS.php';
    include_once '../C/CSC.php';

    $error = "";

    // create 
    $categorie_Service = null;
	$nom = $_POST["nom_cs"] ?? "";
	//$alpha = true;
    // create an instance of the controller
    $categorieSerC = new CategorieSerC();
    if (
		isset($_POST["nom_cs"]) &&		
        isset($_POST["image_cs"]) 
		    ) {
        if (ctype_alpha($nom) &&
			!empty($_POST['nom_cs']) &&
            !empty($_POST["image_cs"]) 
        ) {
            $categorie_Service = new Categorie_Service(
          
				$_POST['nom_cs'],
                $_POST['image_cs']
				);
            $categorieSerC->ajouterCat_ser($categorie_Service);
            header('Location:afficherCtgs.php');
        }
		else
            $error = "Missing information or invalid name";
			}

    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>
    <body>
        <button><a href="afficherCtgs.php">Retour à la liste des categories</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="ID_cs">ID de categorie de service va etre affecte automatiquement pour eviter les prob:
                        </label>
                    </td>
                    <td>
						<input type="hidden" name="ID_cs" id="ID_cs" >
					</td>
                </tr>
				<tr>
                    <td>
                        <label for="nom_cs">Nom :
                        </label>
                    </td>
                    <td><input type="text" name="nom_cs" id="nom_cs" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="image">image:
                        </label>
                    </td>
                    <td><input type="text" name="image_cs" id="image_cs" maxlength="20"></td>
                </tr>
                              
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Envoyer"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>