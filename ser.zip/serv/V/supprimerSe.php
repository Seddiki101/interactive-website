<?php
	include '../C/CSC.php';
	$serviceC=new ServiceC();
	$serviceC->supprimerservice($_GET["IDs"]);
	header('Location:afficherSe.php');
?>