<?php
    include_once '../M/CS.php';
    include_once '../C/CSC.php';

    $error = "";

    // create 
    $service = null;

    // create an instance of the controller
	
	//$_POST["IDs"] == value of id of a form
    $serviceC = new ServiceC();
    if (
        isset($_POST["IDs"]) &&  
		isset($_POST["nom_ser"]) &&		
        isset($_POST["image_ser"]) &&
		isset($_POST["frais"]) && 
        isset($_POST["Description"]) && 
        isset($_POST["ID_cs"])
    ) {
        if (
            !empty($_POST["IDs"]) && 
			!empty($_POST['nom_ser']) &&
            !empty($_POST["image_ser"]) && 
			!empty($_POST["frais"]) && 
            !empty($_POST["Description"]) && 
            !empty($_POST["ID_cs"])
        ) {
            $service = new Service(
                $_POST['IDs'],
				$_POST['nom_ser'],
                $_POST['image_ser'], 
				$_POST['frais'],
                $_POST['Description'],
                $_POST['ID_cs']
            );
            $serviceC->ajouterservice($service);
            header('Location:afficherSe.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>
</head>
    <body>
        <button><a href="afficherSe.php">Retour à la liste </a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="IDs">Numéro Service :
						<input type="number" name="IDs" id="IDs">
                        </label>
                    </td>
                </tr>
				<tr>
                    <td>
                        <label for="nom_ser">Nom Service:
                        </label>
                    </td>
                    <td><input type="text" name="nom_ser" id="nom_ser" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="image_ser">Image:
                        </label>
                    </td>
                    <td><input type="text" name="image_ser" id="image_ser" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="frais">Frais:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="frais" id="frais">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="email">Description:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="Description" id="Description">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="ID_cs">ID_cs:
                        </label>
                    </td>
                    <td>
                        <input type="number" name="ID_cs" id="ID_cs" >
                    </td>
                </tr>              
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Envoyer"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>